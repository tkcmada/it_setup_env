//= require_tree /asset-pipeline/test/absolute-path/tree
//= require_tree asset-pipeline/test/absolute-path/not-included