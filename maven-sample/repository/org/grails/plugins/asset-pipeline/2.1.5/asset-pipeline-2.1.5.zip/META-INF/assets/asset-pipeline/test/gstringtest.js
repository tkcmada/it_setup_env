//=require ${"gstringtest2.js"}
