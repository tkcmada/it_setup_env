config = {
	cache {
		name 'grailsBlocksCache'
	}
	cache {
		name 'grailsTemplatesCache'
	}
}
